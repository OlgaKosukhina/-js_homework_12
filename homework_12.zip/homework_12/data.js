const data = `[
    {
        "productItem": "black suit",
        "productID": "02",
        "productDescription": "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
        "Price": "75.00",
        "productImage": "img/products_img/image.png",
        "productImageAlt": "woman_black_suit",
        "cartIcon": "img/cart-icon.svg",
        "productColor": "Black",
        "productSize": "S"
    },
    {
        "productItem": "blue fashion sweatshirt",
        "productID": "03",
        "productDescription": "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
        "Price": "22.00",
        "productImage": "img/products_img/boy_1.png",
        "productImageAlt": "man_blue_sweetshirt",
        "cartIcon": "img/cart-icon.svg",
        "productColor": "Blue",
        "productSize": "M"
    },
    {
        "productItem": "man yellow pants",
        "productID": "04",
        "productDescription": "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
        "Price": "32.00",
        "productImage": "img/products_img/man_2.png",
        "productImageAlt": "man_yellow_pants",
        "cartIcon": "img/cart-icon.svg",
        "productColor": "Yellow",
        "productSize": "L"
    },
    {
        "productItem": "new blue jacket",
        "productID": "05",
        "productDescription": "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
        "Price": "80.00",
        "productImage": "img/products_img/woman_2.png",
        "productImageAlt": "woman_blue_jacket",
        "cartIcon": "img/cart-icon.svg",
        "productColor": "Blue",
        "productSize": "XS"
    },
    {
        "productItem": "light green shirt",
        "productID": "06",
        "productDescription": "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
        "Price": "22.00",
        "productImage": "img/products_img/woman_3.png",
        "productImageAlt": "woman_green_shirt",
        "cartIcon": "img/cart-icon.svg",
        "productColor": "Green",
        "productSize": "S"
    }
]`